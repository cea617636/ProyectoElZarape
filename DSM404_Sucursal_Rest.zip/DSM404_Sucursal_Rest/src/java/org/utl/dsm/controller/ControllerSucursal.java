/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.utl.dsm.controller;

import java.util.List;
import org.utl.dsm.model.*;
import java.sql.*;
import java.util.ArrayList;

public class ControllerSucursal {
    public List<Sucursal> getAll() throws SQLException{
        System.out.println("Llegamos al controller");
        String query = "SELECT * FROM sucursal INNER JOIN ciudad ON sucursal.idCiudad = ciudad.idCiudad;";
        ConecctionMysql connMysql = new ConecctionMysql();
        Connection conn =  connMysql.open();
        PreparedStatement pstm = conn.prepareStatement(query);
        ResultSet rs = pstm.executeQuery();
        List<Sucursal> sucursales = new ArrayList<>();
        while(rs.next()){
            sucursales.add(fill(rs));
        }
        rs.close();
        conn.close();
        return sucursales;
    }

    private Sucursal fill(ResultSet rs) throws SQLException {
        Sucursal s = new Sucursal();
        Ciudad c = new Ciudad();
        
        s.setIdSucursal(rs.getInt("idSucursal"));
        s.setNombre(rs.getString("nombre"));
        s.setLatitud(rs.getString("latitud"));
        s.setLongitud(rs.getString("longitud"));
        s.setFoto(rs.getString("foto"));
        s.setUrlWeb(rs.getString("urlWeb"));
        s.setHorarios(rs.getString("horarios"));
        s.setCalle(rs.getString("calle"));
        s.setNumCalle(rs.getString("numCalle"));
        s.setColonia(rs.getString("colonia"));
        s.setActivo(rs.getInt("activo"));
        
        c.setIdCiudad(rs.getInt("idCiudad"));
        //c.setNombre(rs.getNString(""));
        s.setCiudad(c);
        return s;
    }
    
    public List<Ciudad> getAllCiudad(String filtro) throws SQLException{
        String query = "SELECT * FROM ciudad WHERE nombre LIKE '"+filtro+"%' ORDER BY nombre;";
        ConecctionMysql connMysql = new ConecctionMysql();
        Connection conn =  connMysql.open();
        PreparedStatement pstm = conn.prepareStatement(query);
        ResultSet rs = pstm.executeQuery();
        List<Ciudad> ciudades = new ArrayList<>();
        while(rs.next()){
            ciudades.add(fillCiudad(rs));
        }
        rs.close();
        conn.close();
        return ciudades;
    }

    private Ciudad fillCiudad(ResultSet rs) throws SQLException {
        Ciudad c = new Ciudad();
        c.setIdCiudad(rs.getInt("idCiudad"));
        c.setNombre(rs.getString("nombre"));
        return c;
    }
    
    
}
