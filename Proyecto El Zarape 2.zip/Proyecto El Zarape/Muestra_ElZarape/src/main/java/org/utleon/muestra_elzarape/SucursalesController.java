package org.utleon.muestra_elzarape;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

public class SucursalesController {
    @FXML
    private Button btnLlamar;

    @FXML
    private TextArea txtRespuesta;

    @FXML
    public void initialize() {
        //Este es el constructor del modulo
        btnLlamar.setOnAction(e -> {
            callService();
        });
    }

    public void callService(){
        String URL = "http://localhost:8080/612_PruebaServidor/api/prueba/saludar";
        new Thread(() ->{
            try {
                HttpResponse<String> response = Unirest.get(URL).asString();
                System.out.println(response.getBody());
                Platform.runLater(() -> {
                    txtRespuesta.setText(response.getBody());
                });
            }catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }).start();
    }

}
