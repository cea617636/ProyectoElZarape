package org.utleon.muestra_elzarape.model;

public class Sucursal {
}
