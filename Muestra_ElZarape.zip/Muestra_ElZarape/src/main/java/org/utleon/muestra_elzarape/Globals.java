package org.utleon.muestra_elzarape;

public class Globals {
    public final String BASE_URL = "http://localhost:8080/elzarape/api/";
}
